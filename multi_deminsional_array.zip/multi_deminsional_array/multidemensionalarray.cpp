#include <iostream>
#include <cstring>
using namespace std;

//******************************
//writen by: Zachary Lessard
//Double Char Array assignment
//******************************

int main(int argc, char** argv) {  //main
	//**********initializations************
	int size = 0; //sets size equal to zero
	int i = 0; //sets i equal to zero
	char **myArray; //initializes the pointer "myArray"
	myArray = new char*[size]; //sets my array equal to the size
	char **newArray = new char*[size]; //sets the size of the new array equal to size
	newArray = myArray; //sets the new array equal to the old array
	char input[80]; //input set as size 80
	//*************************************
   do{ //beginning of the do while.
		cout<<"please say something! type ""quit"" when done: "; //asks the user to enter a sting
		cin>>input; //allows the user to put input
		if(strcmp(input, "quit") == 0){ //if the input is equal to quit, it exits the program.
			break; //break stops the program
		}
		else{ //if it is anything else it runs this code
		myArray[i]  = new char[strlen(input)]; //sets old array equal to strlen
		newArray[i] = new char[strlen(input)]; //sets new array equal to strlen
		strcpy(myArray[i], input); //adds input to the array
		strcpy(newArray[i], myArray[i]); //copys the old array to the new array
		size++; 
		i++;
	}
	
	 
    } while(strcmp (input, "quit") !=  0); //if the input is not equal to "quit"
	myArray = new char*[size]; //sets the old array equal to the pointer size
		delete myArray; //deletes the old array
		myArray = newArray; //to make sure there are no memory leaks, sets old array to the new array.
		
	for(int j =0; j < size; j++){ //for statement that prints out the array.
		cout<<"["<<myArray[j]<<"]";  //prints out the old array, which is now equal to the new array
	}

	
	

	return 0; //returns 0
}
