#ifndef LINKEDLIST_H
#define LINKEDLIST_H

class LinkedList
{
	private:
	public:
	LinkedList();
	insertFront();
	print();
//	~intsertFront();
	int head;
};

#endif
